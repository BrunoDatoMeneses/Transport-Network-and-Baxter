#include "ros/ros.h"
#include <sstream>

// On inclue le message et la librairie
#include "scenario1/EtatZone.h"
#include <modbus/modbus.h>

// On définie l'adresse des cases "état_poste1" et "état_poste2" dans l'automate (sur lequelles on écrira dans les MAE)
#define ADDR_ETAT_P1 51
#define ADDR_ETAT_P2 52

int main(int argc, char **argv)
{
	// On initialise et déclare le noeud
	ros::init(argc, argv, "publisher_zone1");
	ros::NodeHandle n;

	// On abonne le noeud au topic "etat_zone1" qui gère des messages de type "EtatZone" et on lui donne une fréquence de 1 Hz
	ros::Publisher chatter_pub = n.advertise<scenario1::EtatZone>("etat_zone1", 1000);
	ros::Rate loop_rate(1);

	// On teste si le noeud est ouvert
	while (ros::ok())
	{
		// On déclare un message de type "EtatZone" et deux chaînes de caractères
		scenario1::EtatZone msg_etat_poste;
		std::stringstream etat_p1, etat_p2;

		// On déclare ce qui est utile pour Modbus : l'adresse de l'automate à joindre et des variables contenant l'état des 			postes
		modbus_t *ap1;
		ap1 = modbus_new_tcp("192.168.0.101", 502);
		uint16_t tab_etat_p1[1], tab_etat_p2[1];
    
		// On ouvre la liaison Modbus avec l'automate    
		modbus_connect(ap1);


		// Si la fonction modbus_read_registers a fonctionné, on récupère l'état du poste dans l'automate et on le stocke 			dans le message créé plus haut
		// On le fait pour les deux postes de travail
		if (modbus_read_registers(ap1, ADDR_ETAT_P1, 1, tab_etat_p1) > 0) {
			msg_etat_poste.etat_p1 = tab_etat_p1[0];
			ROS_INFO("Passage etat p1 : %ld", msg_etat_poste.etat_p1);		
		}
		else
			ROS_INFO("Erreur etat p1");
	
	   	if (modbus_read_registers(ap1, ADDR_ETAT_P2, 1, tab_etat_p2) > 0) {
			msg_etat_poste.etat_p2 = tab_etat_p2[0];
			ROS_INFO("Passage etat p2 : %ld", msg_etat_poste.etat_p2);		
		}
		else
			ROS_INFO("Erreur etat p2");
	
		// On publie le message contenant l'état des deux postes
    		chatter_pub.publish(msg_etat_poste);

		// On endort le publisher jusqu'au prochain passage dans la boucle (1 Hz)
   		loop_rate.sleep();

	}
 	return 0;
}




