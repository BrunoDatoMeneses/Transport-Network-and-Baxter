//---------------------------------------------------------------------------
// modbus_tcp_seul_2013.h                 B.Vannier mars 2013
//
// Classe  MODBUS_TCP: Gestion du protocole MODBUS TCP
//
// Cette classe permet de:
//  - construire une trame de requete 1,2,3,4,15,16,23   trame_readbit1(..), ...
//  - d�coder la trame r�ponse                          extrait_readbit(..), ...
//
// les requ�tes suivantes sont impl�ment�es:
//      Lecture bits  : code 1
//      Lecture bits  : code 2
//      Lecture mots  : code 3
//      Lecture mots  : code 4
//      Ecriture bits : code 15
//      Ecriture mots : code 16
//      Lecture/Ecriture mots : code 23
//
//---------------------------------------------------------------------------

#define uint unsigned int
#define ushort unsigned short
#define uchar unsigned char


class MODBUS_TCP
{
protected:
  uint transacId_emi, transacId_rec;
  ushort extrait_noreq_rec(uchar * buf);

  int entete_Tcp(uchar * buffer_, int nb1);

public:
  int trame_readbit1(int adr, int nbit, int nes, uchar * Tabemi);
  int trame_readbit2(int adr, int nbit, int nes, uchar * Tabemi);
  int trame_readT3(int adr, int nbmot, int nes, uchar * Tabemi);
  int trame_readT4(int adr, int nbmot, int nes, uchar * Tabemi);
  int trame_writebit(int adr, int nbit, int nes, bool * valeurb, uchar * Tabemi);
  int trame_writeT(int adr, int nbmot, int nes, short * valeur, uchar * Tabemi);
  int extrait_readT(short * valeur, uchar * Tabrec);
  int extrait_readbit(bool * valeur, uchar * Tabrec);

  int trame_read_writeT23(int adrR, int nbmotR,int adrW, int nbmotW, int nes, short * valeur, uchar * Tabemi);
};
