//---------------------------------------------------------------------------

#ifndef ClientModbusTcp4H
#define ClientModbusTcp4H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ScktComp.hpp>
#include <ExtCtrls.hpp>

#include "UnitModbusTCP4.h"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// Composants g�r�s par l'EDI
  TMemo *Memo1;
  TEdit *EditName;
  TLabel *Label1;
  TLabel *Label3;
  TButton *Connecter;
  TButton *Deconnecter;
  TEdit *EditPort;
  TLabel *Label5;
  TButton *Send1;
  TEdit *Edit2;
  TEdit *Edit3;
  TLabel *Label2;
  TLabel *Label4;
  TCheckBox *CheckBox1;
  TButton *SendW;
  TEdit *Edit1;
  TEdit *Edit4;
  TEdit *Edit5;
  TLabel *Label6;
  TButton *bReq23;
  TEdit *Edit6;
  TEdit *Edit7;
  TEdit *Edit8;
  TEdit *Edit9;
  TButton *bLectureBits;
  TButton *bEcritureBits;
  TEdit *Edit10;
  TEdit *Edit11;
  TEdit *Edit12;
  TEdit *Edit13;
  TLabel *Label7;
  TLabel *Label8;

  void __fastcall ConnecterClick(TObject *Sender);
  void __fastcall DeconnecterClick(TObject *Sender);

  void __fastcall Send1Click(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall CheckBox1Click(TObject *Sender);
  void __fastcall SendWClick(TObject *Sender);
  void __fastcall bReq23Click(TObject *Sender);
  void __fastcall bLectureBitsClick(TObject *Sender);
  void __fastcall bEcritureBitsClick(TObject *Sender);

private:	// D�clarations de l'utilisateur
  void __fastcall Post_ReadM(short *tMots, int nbMots);
  void __fastcall Post_ReadB(bool *tBits, int nbBits);
  bool IsServer;
  TModbusTCP *pClientSocket;
  void __fastcall CheckBoxCick(TObject *Sender);
  TCheckBox *pCheck[16];
  TShape *pShape[16];

public:		// D�clarations de l'utilisateur
  __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
