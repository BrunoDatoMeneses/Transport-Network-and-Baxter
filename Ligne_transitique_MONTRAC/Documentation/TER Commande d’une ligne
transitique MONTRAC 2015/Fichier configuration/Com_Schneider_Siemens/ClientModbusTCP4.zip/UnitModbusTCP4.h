//---------------------------------------------------------------------------
// UnitModbusTCP.h             B.Vannier  fev 2011
//---------------------------------------------------------------------------

#ifndef UnitModbusTCP4H
#define UnitModbusTCP4H

#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ScktComp.hpp>
#include <ExtCtrls.hpp>

#include "modbus_tcp_seul_2013.h"

#define uint unsigned int
#define ushort unsigned short
#define uchar unsigned char

// D�finition du type de fonction Post Routine apr�s retour lecture Mots
typedef void __fastcall (__closure *TNotifyReadM)(short*, int);
// D�finition du type de fonction Post Routine apr�s retour lecture Bits
typedef void __fastcall (__closure *TNotifyReadB)(bool*, int);
// D�claration de cette Post Routine dans le module appelant:
//   void __fastcall Post_Read(short *tMots, int nbMots);

//---------------------------------------------------------------------------
// Classe TModbusTCP
//---------------------------------------------------------------------------
class TModbusTCP : public TClientSocket
{
  public:
  TModbusTCP( TWinControl* Control, TMemo *pMemo_);  // constructeur
  TModbusTCP( TWinControl* Control, TMemo *pMemo_, TNotifyReadM pPostFuncM, TNotifyReadB pPostFuncB);
  int Connect(AnsiString StrAdIP, int noPort);
  int DisConnect();
  int ReadW3(int adr, int nbmot);
  int extraitReadT(short * valeur);
  int ReadB1(int adr, int nbits);
  //int extraitReadB(bool * valeur);
  int WriteT(int adr, int nbmot, short * valeur);
  int WriteB15(int adr, int nbmot, bool * valeur);
  int ReadWriteT(int adrR, int nbmotsR, int adrW, int nbmotsW, short * valeur);
  bool bAffich;

  protected:
  void init(TMemo *pMemo, TNotifyReadM pPostFuncM_, TNotifyReadB pPostFuncB_);
  void __fastcall fClientSocketConnect(TObject *Sender,
          TCustomWinSocket *Socket);
  void __fastcall fClientSocketDisconnect(TObject *Sender,
          TCustomWinSocket *Socket);
  void __fastcall fClientSocketError(TObject *Sender,
          TCustomWinSocket *Socket, TErrorEvent ErrorEvent,
          int &ErrorCode);
  void __fastcall fClientSocketRead(TObject *Sender,
          TCustomWinSocket *Socket);

  AnsiString TModbusTCP::Affich_trame(char *buf, int nb, AnsiString AsChaine);
  AnsiString Affich_mots(short *buf, int nb, AnsiString AsChaine);
  MODBUS_TCP modbus1;  // pour construction des trames et d�codage r�ponse
  uchar Tabemi[1024], Tabrec[1024]; // buffers �mission, r�ception
  short tabMots[256];  // table des mots lus
  bool tabBits[1024];  // table des bits lus
  TMemo *pMemo;
  TNotifyReadM fPostReadM;    // Post routine � fin requ�te lecture mots
  TNotifyReadB fPostReadB;    // Post routine � fin requ�te lecture bits
};
#endif
