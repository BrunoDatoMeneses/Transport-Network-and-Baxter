//---------------------------------------------------------------------------
// ClientModbusTcp2.cpp             B.Vannier  23 fev 2011
// exemple Client Modbus TCP
// Appel d'une unit� externe: UnitModbusTCP.cpp
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "ClientModbusTcp4.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  pClientSocket  = new TModbusTCP((TWinControl*)Form1, Memo1, &Post_ReadM, &Post_ReadB);  // cr�ation dynamique d'un nouvel objet

  // Cr�ation des Shape pour l'affichage des entr�es bits  Simu -> Superviseur
  for (int i=0; i<16; i++) {
    pShape[i] = new TShape((TComponent*)Form1);
    pShape[i]->Parent = Form1;
    pShape[i]->Height = 16;
    pShape[i]->Width = 12;
    pShape[i]->Brush->Color = clGray;
    pShape[i]->Tag = i;
    pShape[i]->Top = 390;
    pShape[i]->Left = 440 - (16*i) - (i&8);
//    pShape[i]->OnMouseDown = ShapeOMouseDown;
  }
  // Cr�ation des CheckBox pour le positionnement des sorties Superviseur -> Simu 
  for (int i=0; i<16; i++) {
    pCheck[i] = new TCheckBox((TComponent*)Form1);
    pCheck[i]->Parent = Form1;
    pCheck[i]->Height = 16;
    pCheck[i]->Width = 12;
    pCheck[i]->Tag = i+16;
    pCheck[i]->Top = 430;
    pCheck[i]->Left = 440 - (16*i) - (i&8);
    pCheck[i]->OnClick = CheckBoxCick;
  }
}
//---------------------------------------------------------------------------
// Fonctions li�es au boutons de Form1
//---------------------------------------------------------------------------
void __fastcall TForm1::ConnecterClick(TObject *Sender)
{
  pClientSocket->Connect( EditName->Text, EditPort->Text.ToIntDef(502));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DeconnecterClick(TObject *Sender)
{
  pClientSocket->DisConnect();
}
//---------------------------------------------------------------------------
// Send1Click() envoi requete lecture
//---------------------------------------------------------------------------
void __fastcall TForm1::Send1Click(TObject *Sender)
{
   pClientSocket->ReadW3(Edit2->Text.ToInt(), Edit3->Text.ToInt());
}
//---------------------------------------------------------------------------
void __fastcall TForm1::CheckBox1Click(TObject *Sender)
{
  pClientSocket->bAffich = CheckBox1->Checked ;  
}
//---------------------------------------------------------------------------
// Post_ReadM() Cette fonction est appel�e par pClientSocket au retour trame lecture Mots
//---------------------------------------------------------------------------
void __fastcall TForm1::Post_ReadM(short *tMots, int nbMots)//(TObject *Sender)
{
  Memo1->Lines->Add("Read: " + IntToStr(nbMots) + " mots lus 1er Mot: " + IntToStr(tMots[0]));
}
//---------------------------------------------------------------------------
// Post_ReadB() Cette fonction est appel�e par pClientSocket au retour trame lecture Bits
//---------------------------------------------------------------------------
void __fastcall TForm1::Post_ReadB(bool *tBits, int nbits)//(TObject *Sender)
{
  Memo1->Lines->Add("Read: " + IntToStr(nbits) + " bits lus"); // 1er Mot: " + IntToStr(tMots[0]));

  for (int i=0; i<16; i++)
  {
    if ( tBits[i] ) pShape[i]->Brush->Color = clRed;
    else pShape[i]->Brush->Color = clBlack;
  }
}
//---------------------------------------------------------------------------
// SendWClick() envoi requete ecriture
//---------------------------------------------------------------------------
void __fastcall TForm1::SendWClick(TObject *Sender)
{
  short valeurs[256];
  valeurs[0] =  Edit5->Text.ToInt();
  valeurs[1] =  Edit6->Text.ToInt();
  valeurs[2] =  Edit7->Text.ToInt();
  valeurs[3] =  Edit8->Text.ToInt();
  valeurs[4] =  Edit9->Text.ToInt();
  pClientSocket->WriteT(Edit1->Text.ToInt(), Edit4->Text.ToInt(), valeurs);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::bReq23Click(TObject *Sender)
{
  short valeurs[256];
  valeurs[0] =  Edit5->Text.ToInt();
  valeurs[1] =  Edit6->Text.ToInt();
  valeurs[2] =  Edit7->Text.ToInt();
  valeurs[3] =  Edit8->Text.ToInt();
  valeurs[4] =  Edit9->Text.ToInt();
  pClientSocket->ReadWriteT(Edit2->Text.ToInt(), Edit3->Text.ToInt(),
                            Edit1->Text.ToInt(), Edit4->Text.ToInt(), valeurs);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::CheckBoxCick(TObject *Sender)
{   // appel� sur clic des CheckBox
  TCheckBox* pObj = (TCheckBox*)Sender;
  //esclave1.Btable[pObj->Tag] =  pObj->Checked;     // mise � jour %Mxx
}
//---------------------------------------------------------------------------

void __fastcall TForm1::bLectureBitsClick(TObject *Sender)
{
  int ad= Edit10->Text.ToInt();
  int nb = Edit12->Text.ToInt();
  int cr = pClientSocket->ReadB1(ad, nb);

}
//---------------------------------------------------------------------------

void __fastcall TForm1::bEcritureBitsClick(TObject *Sender)
{
  bool valeurb[16]; // tableau de valeur booleennes
  for (int i=0; i<16; i++)
  {
    valeurb[i] = pCheck[i]->Checked ;
  }
  int ad= Edit11->Text.ToInt();
  int nb = Edit13->Text.ToInt();
  pClientSocket->WriteB15(ad, nb, valeurb);

}
//---------------------------------------------------------------------------

