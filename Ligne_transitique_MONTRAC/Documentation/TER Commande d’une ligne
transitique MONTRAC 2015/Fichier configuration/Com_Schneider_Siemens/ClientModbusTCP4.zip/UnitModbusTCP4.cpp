//---------------------------------------------------------------------------
// UnitModbusTCP.cpp             B.Vannier  fev 2011
// Unit� Client Modbus TCP
// A int�grer dans un projet
//---------------------------------------------------------------------------
#pragma hdrstop

#include "UnitModbusTCP4.h"  // ne pas oublier ...
#pragma package(smart_init)
//---------------------------------------------------------------------------
//  TModbusTCP : constructeurs
//---------------------------------------------------------------------------
TModbusTCP::TModbusTCP( TWinControl* Control, TMemo *pMemo_)
  :TClientSocket(Control)   // appel du constructeur h�rit�
{
  init(pMemo_, NULL, NULL);
}
//-----------------------------------------
TModbusTCP::TModbusTCP( TWinControl* Control, TMemo *pMemo_, TNotifyReadM pPostFuncM_, TNotifyReadB pPostFuncB_)
  :TClientSocket(Control)   // appel du constructeur h�rit�
{
  init(pMemo_, pPostFuncM_, pPostFuncB_);
}
//------------------------------------------
void TModbusTCP::init(TMemo *pMemo_, TNotifyReadM fPostReadM_, TNotifyReadB fPostReadB_)
{
  Port = 502;    // par d�faut
  Address = "127.0.0.1";
  pMemo = pMemo_;
  if (pMemo!=NULL) bAffich = true;  // bAffich peut �tre mis � false par la suite
  else bAffich = false;    // le pointeur �tait NULL!

  // initialisation des "post-routines"
  this->OnConnect = fClientSocketConnect;
  this->OnDisconnect = fClientSocketDisconnect;
  this->OnError = fClientSocketError;
  this->OnRead = fClientSocketRead;
  fPostReadM = fPostReadM_;
  fPostReadB = fPostReadB_;
}
//---------------------------------------------------------------------------
// Connect()
//---------------------------------------------------------------------------
int TModbusTCP::Connect(AnsiString StrAdIP, int noPort)
{
  Address = StrAdIP;
  Port = noPort;
  Active = true;
  return (0);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
int TModbusTCP::DisConnect()
{
  Active = false;
  return (0);
}
//---------------------------------------------------------------------------
//  ReadW3()  
//---------------------------------------------------------------------------
int TModbusTCP::ReadW3(int adr, int nbmots)
{
  int lg = modbus1.trame_readT3(adr, nbmots, 1, Tabemi);
  Socket->SendBuf( Tabemi, lg);
  AnsiString AsSend;
  if (bAffich) pMemo->Lines->Add("->API : " + Affich_trame(Tabemi, lg, AsSend));
  return (0);
}
//---------------------------------------------------------------------------
//  ReadB1()
//---------------------------------------------------------------------------
int TModbusTCP::ReadB1(int adr, int nbits)
{
  int lg = modbus1.trame_readbit1(adr, nbits, 1, Tabemi);
  Socket->SendBuf( Tabemi, lg);
  AnsiString AsSend;
  if (bAffich) pMemo->Lines->Add("->API : " + Affich_trame(Tabemi, lg, AsSend));
  return (0);
}
//---------------------------------------------------------------------------
//  extraitReadT()   A terminer
//---------------------------------------------------------------------------
int TModbusTCP::extraitReadT(short * valeur)
{
  return (0);
}
//---------------------------------------------------------------------------
// WriteT()  A terminer
//---------------------------------------------------------------------------
int TModbusTCP::WriteT(int adr, int nbmots, short * valeur)
{
  int lg = modbus1.trame_writeT(adr, nbmots, 1, valeur, Tabemi);
  Socket->SendBuf( Tabemi, lg);
  AnsiString AsSend;
  if (bAffich) pMemo->Lines->Add("->API : " + Affich_trame(Tabemi, lg, AsSend));
  return (0);
}
//---------------------------------------------------------------------------
// WriteB15(int adr, int nbmot, bool * valeur)
//---------------------------------------------------------------------------
int TModbusTCP::WriteB15(int adr, int nbits, bool * valeur)
{
  int lg = modbus1.trame_writebit(adr, nbits, 1, valeur, Tabemi);
  Socket->SendBuf( Tabemi, lg);
  AnsiString AsSend;
  if (bAffich) pMemo->Lines->Add("->API : " + Affich_trame(Tabemi, lg, AsSend));
  return (0);
}
//---------------------------------------------------------------------------
// ReadWriteT()  A terminer
//---------------------------------------------------------------------------
int TModbusTCP::ReadWriteT(int adrR, int nbmotsR, int adrW, int nbmotsW, short * valeur)
{
  int lg = modbus1.trame_read_writeT23(adrR, nbmotsR,adrW, nbmotsW, 1, valeur, Tabemi);
  Socket->SendBuf( Tabemi, lg);
  AnsiString AsSend;
  if (bAffich) pMemo->Lines->Add("->API : " + Affich_trame(Tabemi, lg, AsSend));
  return (0);
}
//---------------------------------------------------------------------------
// Evennements li�s au ClientSocket
//---------------------------------------------------------------------------

void __fastcall TModbusTCP::fClientSocketConnect(TObject *Sender,
      TCustomWinSocket *Socket)
{
  if (bAffich) pMemo->Lines->Add("Connected to: " + Socket->RemoteAddress );
}
//---------------------------------------------------------------------------

void __fastcall TModbusTCP::fClientSocketDisconnect(TObject *Sender,
      TCustomWinSocket *Socket)
{
  if (bAffich) pMemo->Lines->Add("Disconnect from: " + Socket->RemoteAddress);
}
//---------------------------------------------------------------------------
void __fastcall TModbusTCP::fClientSocketRead(TObject *Sender,
      TCustomWinSocket *Socket)
{
  AnsiString AsRecept;
  int lg = Socket->ReceiveLength();
  Socket->ReceiveBuf(Tabrec, 256);

  if (bAffich) pMemo->Lines->Add("API ->: " + Affich_trame(Tabrec, lg, AsRecept));

  int cr = 0;
  int noReq = Tabrec[7];
  switch (noReq) {
    case 3:
    case 23:
    case 4:cr = modbus1.extrait_readT(tabMots, Tabrec);
           if (bAffich)
              pMemo->Lines->Add(IntToStr(cr) + " mots lus: " + Affich_mots(tabMots, cr, AsRecept));
           break;
    case 1:
    case 2: cr = modbus1.extrait_readbit(tabBits, Tabrec);
           if (bAffich)
              pMemo->Lines->Add(IntToStr(cr) + " bits lus ");
           break;
    case 16:
    case 15: break;
    default: if (bAffich) pMemo->Lines->Add("Retour requ�te non reconnue: " + IntToStr(noReq));
  }
  if (cr < 0) {
    if (bAffich) pMemo->Lines->Add("Erreur " + IntToStr(noReq) + "   Retour requ�te " + IntToStr(cr));
    return;
  }

  if (fPostReadM!=NULL) {
    if ((noReq == 3)||(noReq == 4)||(noReq == 23)){
      fPostReadM(tabMots, cr);
    }
  }
  if (fPostReadB!=NULL) {
    if ((noReq == 1)||(noReq == 2)){
      fPostReadB(tabBits, cr);
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TModbusTCP::fClientSocketError(TObject *Sender,
      TCustomWinSocket *Socket, TErrorEvent ErrorEvent, int &ErrorCode)
{
  if (bAffich) pMemo->Lines->Add("Error connecting to:" + Address);
  ErrorCode = 0;
}
//---------------------------------------------------------------------------
// Affich_trame() : Charge dans un AnsiString le contenu de la trame binaire buf
//                  mais en repr�sentation Hexad�cimale
//---------------------------------------------------------------------------
AnsiString TModbusTCP::Affich_trame(char *buf, int nb, AnsiString AsChaine)
{
  int i;
  bool Bhexa=false;
  for (i=0; i<(nb-1); i++){  // Est ce une chaine ASCII?
    if ((unsigned)buf[i] < 9) {
      Bhexa = true; break;   // Non
    }
  }
  if (Bhexa){
    for (int i=0; i<nb; i++){
      AsChaine = AsChaine + IntToHex((buf[i]&0xFF), 2) + " ";
    }
  }
  else {
    if (buf[nb-1]!=0) buf[nb] = 0; // rajout du d�limiteur de fin de chaine?
    AsChaine += buf;
  }
  return (AsChaine);
}
//---------------------------------------------------------------------------
// Affich_mots() : Charge dans un AnsiString le contenu du tableau de short buf
//                  mais en repr�sentation Hexad�cimale
//---------------------------------------------------------------------------
AnsiString TModbusTCP::Affich_mots(short *buf, int nb, AnsiString AsChaine)
{
  for (int i=0; i<nb; i++){
    AsChaine = AsChaine + IntToHex((buf[i]&0xFFFF), 4) + " ";
  }
  return (AsChaine);
}
//---------------------------------------------------------------------------


