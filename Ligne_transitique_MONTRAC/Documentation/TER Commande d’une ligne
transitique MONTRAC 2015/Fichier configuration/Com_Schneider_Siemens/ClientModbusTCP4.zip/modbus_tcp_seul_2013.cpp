//---------------------------------------------------------------------------
// modbus_tcp_seul_2013.cpp               B.Vannier mars 2013
//
// Classe  MODBUS_TCP: Gestion du protocole MODBUS TCP
//
// Cette classe permet de:
//  - construire une trame de requete 1,2,3,4,15,16,23   trame_readbit1(..), ...
//  - d�coder la trame r�ponse                          extrait_readbit(..), ...
//
// les requ�tes suivantes sont impl�ment�es:
//      Lecture bits  : code 1
//      Lecture bits  : code 2
//      Lecture mots  : code 3
//      Lecture mots  : code 4
//      Ecriture bits : code 15
//      Ecriture mots : code 16
//      Lecture/Ecriture mots : code 23
//
//
//---------------------------------------------------------------------------
// m�thodes publiques:
//  int trame_readbit1(int adr, int nbit, int nes, uchar * Tabemi)
//  int trame_readbit2(int adr, int nbit, int nes, uchar * Tabemi)
//  int trame_readT3(int adr, int nbmot, int nes, uchar * Tabemi)
//  int trame_readT4(int adr, int nbmot, int nes, uchar * Tabemi)
//  int trame_writebit(int adr, int nbit, int nes, bool * valeurb, uchar * Tabemi)
//  int trame_writeT(int adr, int nbmot, int nes, short * valeur, uchar * Tabemi)
//  int extrait_readT(short * valeur, uchar * Tabrec)
//  int extrait_readbit(bool * valeur, uchar * Tabrec)
//        avril 2012 code requete 23:
//  int trame_read_writeT23(int adrR, int nbmotR,int adrW, int nbmotW, int nes, short * valeur, uchar * Tabemi)
//------------------------------------------------------------------------
// Modifs:
//  janv 2013: trame_read_writeT23()
//------------------------------------------------------------------------
#include "modbus_tcp_seul_2013.h"
//---------------------------------------------------------------------------
// class MODBUS_TCP
//---------------------------------------------------------------------------

//--------------------------------
// renvoie le no de requ�te
ushort MODBUS_TCP::extrait_noreq_rec(uchar * buf)
{
    return ((ushort)((int)((buf[0] << 8) & 0xFF00) + (buf[1] & 0xFF)));
}
//--------------------------------
int MODBUS_TCP::entete_Tcp(uchar * buffer_, int nb1)
{
    transacId_emi++;
    buffer_[0] = (uchar)(transacId_emi >> 8); ;   // transaction identifier - copied by server
    buffer_[1] = (uchar)(transacId_emi & 0xFF); ; // transaction identifier - copied by server
    buffer_[2] = 0;     // protocol identifier MODBUS = 0
    buffer_[3] = 0;     // protocol identifier MODBUS = 0
    int nb2 = nb1 - 6;
    buffer_[4] = (uchar)(nb2 >> 8);     // longueur trame  poids forts
    buffer_[5] = (uchar)(nb2); // longueur trame  poids faibles
    return (nb1);       // longueur de la trame 
}
//----------------------------------------------------------------------------
int MODBUS_TCP::trame_readbit1(int adr, int nbit, int nes, uchar * Tabemi)
{
    Tabemi[6] = (uchar)(nes & 0xFF);       // No d'esclave
    Tabemi[7] = 1;                // No de fonction
    Tabemi[8] = (uchar)((adr >> 8) & 0xFF);  // adresse
    Tabemi[9] = (uchar)(adr & 0xFF);
    Tabemi[10] = (uchar)((nbit >> 8) & 0xFF);// nb de bits
    Tabemi[11] = (uchar)(nbit & 0xFF);
    return (entete_Tcp(Tabemi, 12));
}
//----------------------------------------------------------------------------
int MODBUS_TCP::trame_readbit2(int adr, int nbit, int nes, uchar * Tabemi)
{
    int nb = trame_readbit1(adr, nbit, nes, Tabemi);
    Tabemi[7] = 2;                // No de fonction
    return (entete_Tcp(Tabemi, 12));
}
//----------------------------------------------------------------------------
int MODBUS_TCP::trame_readT3(int adr, int nbmot, int nes, uchar * Tabemi)
{
    Tabemi[6] = (uchar)(nes & 0xFF);       // No d'esclave
    Tabemi[7] = 3;                // No de fonction
    Tabemi[8] = (uchar)((adr >> 8) & 0xFF);  // adresse
    Tabemi[9] = (uchar)(adr & 0xFF);
    Tabemi[10] = (uchar)((nbmot >> 8) & 0xFF);// nb de mots
    Tabemi[11] = (uchar)(nbmot & 0xFF);
    return (entete_Tcp(Tabemi, 12));
}
//----------------------------------------------------------------------------
int MODBUS_TCP::trame_readT4(int adr, int nbmot, int nes, uchar * Tabemi)
{
    int nb = trame_readT3(adr, nbmot, nes, Tabemi);
    Tabemi[7] = 4;                // No de fonction
    return (entete_Tcp(Tabemi, 12));
}
//----------------------------------------------------------------------------
int MODBUS_TCP::trame_writebit(int adr, int nbit, int nes, bool * valeurb, uchar * Tabemi)
{
    int i, j, nboctet;
    uchar octet;

    Tabemi[6] = (uchar)(nes & 0xFF);         // No d'esclave
    Tabemi[7] = 15;                         // No de fonction 15 �criture bits
    Tabemi[8] = (uchar)((adr >> 8) & 0xFF);  // adresse
    Tabemi[9] = (uchar)(adr & 0xFF);
    Tabemi[10] = (uchar)((nbit >> 8) & 0xFF);// nb de mots
    Tabemi[11] = (uchar)(nbit & 0xFF);
    nboctet = (nbit + 7) >> 3;              // nb d'octets utiles
    Tabemi[12] = (uchar)nboctet;             // nb d'octets

    for (i = 0; i < nboctet; i++)
    {   // octet par octet
        octet = 0;
        for (j = 0; j < 8; j++)
        {        // puis bit par bit
            if (valeurb[(i << 3) + j]) octet = (uchar)((int)octet | (1 << j));
        }
        Tabemi[i + 13] = (uchar)octet;
    }

    return (entete_Tcp(Tabemi, nboctet + 13));
}
//----------------------------------------------------------------------------
int MODBUS_TCP::trame_writeT(int adr, int nbmot, int nes, short * valeur, uchar * Tabemi)
{
    int i, nboctet;

    Tabemi[6] = (uchar)(nes & 0xFF);       // No d'esclave
    Tabemi[7] = 16;                // No de fonction
    Tabemi[8] = (uchar)((adr >> 8) & 0xFF);  // adresse
    Tabemi[9] = (uchar)(adr & 0xFF);
    Tabemi[10] = (uchar)((nbmot >> 8) & 0xFF);// nb de mots
    Tabemi[11] = (uchar)(nbmot & 0xFF);
    Tabemi[12] = (uchar)(nbmot << 1);       // nb d'octets

    for (i = 0; i < nbmot; i++)
    {
        Tabemi[13 + (i << 1)] = (uchar)((valeur[i] >> 8) & 0xFF);
        Tabemi[14 + (i << 1)] = (uchar)(valeur[i] & 0xFF);
    }
    nboctet = 13 + (nbmot << 1);
    return (entete_Tcp(Tabemi, nboctet));
}
//---------------------------------------------------------------------------
// trame_read_writeT23: Fonction 23 modbus, construction  trame requete
//----------------------------------------------------------------------------
int MODBUS_TCP::trame_read_writeT23(int adrR, int nbmotR,int adrW, int nbmotW, int nes, short * valeurW, uchar * Tabemi)
{
    int i, nboctet;

    Tabemi[6] = (uchar)(nes & 0xFF);       // No d'esclave
    Tabemi[7] = 23;                // No de fonction

    Tabemi[8] = (uchar)((adrR >> 8) & 0xFF);  // adresse
    Tabemi[9] = (uchar)(adrR & 0xFF);
    Tabemi[10] = (uchar)((nbmotR >> 8) & 0xFF);// nb de mots
    Tabemi[11] = (uchar)(nbmotR & 0xFF);

    Tabemi[12] = (uchar)((adrW >> 8) & 0xFF);  // adresse
    Tabemi[13] = (uchar)(adrW & 0xFF);
    Tabemi[14] = (uchar)((nbmotW >> 8) & 0xFF);// nb de mots
    Tabemi[15] = (uchar)(nbmotW & 0xFF);

    Tabemi[16] = (uchar)(nbmotW << 1);       // nb d'octets

    for (i = 0; i < nbmotW; i++)
    {
        Tabemi[17 + (i << 1)] = (uchar)((valeurW[i] >> 8) & 0xFF);
        Tabemi[18 + (i << 1)] = (uchar)(valeurW[i] & 0xFF);
    }
    nboctet = 17 + (nbmotW << 1);
    return (entete_Tcp(Tabemi, nboctet));
}
//---------------------------------------------------------------------------
// extrait_readT : Fonction 3, 4 ou 23 modbus, analyse de la trame retour
// version Modbus TCP
//----------------------------------------------------------------------------
int MODBUS_TCP::extrait_readT(short * valeur, uchar * Tabrec)
{
    int nbmot, i, requete;
    transacId_rec = extrait_noreq_rec(Tabrec);   // on stocke le transaction identifier re�u
    requete = Tabrec[7];
    if ((requete == 4) || (requete == 3) || (requete == 23))
    {
        nbmot = Tabrec[8] >> 1;    // nombre de mots lus = nb octets / 2
        for (i = 0; i < nbmot; i++)
        {
            valeur[i] = (short)((int)(Tabrec[(i << 1) + 10]) | ((short)(Tabrec[(i << 1) + 9]) << 8));
        }
        return (nbmot);
    }
    else return (-3);
  }
//----------------------------------------------------------------------------
// extrait_readbit : Fonction 1 ou 2 modbus, analyse de la trame retour
// version Modbus TCP
//----------------------------------------------------------------------------
int MODBUS_TCP::extrait_readbit(bool * valeur, uchar * Tabrec)
{
    int nbit, i, j, requete;
    uchar octet;

    transacId_rec = extrait_noreq_rec(Tabrec);   // on stocke le transaction identifier re�u
    requete = Tabrec[7];
    if ((requete == 1) || (requete == 2))
    {
        nbit = (Tabrec[8]) << 3;    // nbits = nb d'octets x 8
        for (i = 0; i < Tabrec[8]; i++)
        {   // octet par octet
            octet = (uchar)(Tabrec[i + 9]);
            for (j = 0; j < 8; j++)
            {             // puis bit par bit
                if (((octet >> j) & 1) != 0) valeur[(i << 3) + j] = true;
                else valeur[(i << 3) + j] = false;
            }
        }
        return (nbit);
    }
    else return (-3);
}

