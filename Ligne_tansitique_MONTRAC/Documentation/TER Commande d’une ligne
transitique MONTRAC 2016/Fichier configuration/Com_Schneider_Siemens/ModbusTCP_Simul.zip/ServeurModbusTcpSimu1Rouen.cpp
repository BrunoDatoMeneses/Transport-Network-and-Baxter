//---------------------------------------------------------------------------
// Serveur MODBUS TCP de simulation PO B.Vannier Rouen 2013
// Protocole MODBUS TCP:
//---------------------------------------------------------------------------
// Modifs:
//  30 avril 13: rajout requete 23
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "ServeurModbusTcpSimu1Rouen.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
// ToHexa()
//---------------------------------------------------------------------------
AnsiString* TForm1::ToHexa(AnsiString* As, char *buf, int lg)
{
  for (int i=0; i< lg; i++) {
    *As += IntToHex( ((int) buf[i])&0xFF, 2) + " ";
  }
  return (As);
}
//---------------------------------------------------------------------------
// Serveur
//---------------------------------------------------------------------------
void __fastcall TForm1::ServerSocket1Accept(TObject *Sender,
      TCustomWinSocket *Socket)
{
  //Memo2->Lines->Add( "Connect to: " + Socket->RemoteAddress);
  Edit2->Text = Socket->RemoteAddress;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ServerSocket1ClientConnect(TObject *Sender,
      TCustomWinSocket *Socket)
{
  Memo2->Lines->Add("Le Client " + Socket->RemoteAddress + " est connect�");
  nouveauClient(Sender, (TServerWinSocket*)Socket);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ServerSocket1ClientDisconnect(TObject *Sender,
      TCustomWinSocket *Socket)
{
  Memo2->Lines->Add( "Le Client " + Socket->RemoteAddress + " est d�connect�");
  departClient(Sender, (TServerWinSocket*)Socket);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ServerSocket1ClientRead(TObject *Sender,
      TCustomWinSocket *Socket)
{
  AnsiString AsStr;
  char  bufem[256];

  TMOT *pMot1=NULL;

  // Recherche de l'appelant dans la liste
  for (int i=0 ; ;  i++) {
    pMot1 = &mot.at(i);
    if (Socket == pMot1->sock ) {
      break;  // l'appelant est trouv�
    }
    if ( i >= mot.size() ) {
      Memo2->Lines->Add( "ERREUR: Socsket non trouv�e dans la liste!!!" + IntToStr(Socket));
      return;
    }
  }

//----------- d�but traitement MODBUS TCP
  int nbRec = Socket->ReceiveBuf(bufrec, 256);

  int nbEmi = esclave1.repond( bufem, bufrec, nbRec);
  if (nbEmi < 0) {
    Memo2->Lines->Add( ": Erreur trame TCP/Modbus:" + IntToStr(nbEmi));
    return ;
  }

  int cr = Socket->SendBuf(bufem, nbEmi);   //send(Sender->SocketClient_, buf_out, nb,0);
  if (cr < 0) {
    Memo2->Lines->Add( "Erreur send" + IntToStr(cr));
    return;
  }
  else{
    AnsiString Aschaine = "->Client: ";
    //if (CheckBox3->Checked) Memo2->Lines->Add(Affich_trame(bufem, nb, Aschaine));
  }
//----------- fin traitement sp�cifique MODBUS TCP

  AsStr = pMot1->sock->RemoteAddress + " | ";

  //
  // Mise a jour des objets graphiques lies aux Mots MODBUS
  //
  for (int i=0; i<4; i++) {
    for (int j=0; j<16; j++) {
      if ( esclave1.Itable[i] & (1 << j) ) pShapeOut[(i<<4)+j]->Brush->Color = clRed;
      else pShapeOut[(i<<4)+j]->Brush->Color = clGray;
    }
  }

  RefreshMotEnt();


  if (ProgressBar1->Position >= ProgressBar1->Max) ProgressBar1->Position = 0;
  else ProgressBar1->Position += 1; 

  if (! CheckBox1->Checked ) return;  // pas d'affichage => on sort

  ToHexa(&AsStr, bufrec, nbRec);
  AsStr += " -> ";
  ToHexa(&AsStr, bufem, nbEmi);
  Memo2->Lines->Add(Socket->RemoteAddress + " " + AsStr);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ServerSocket1ClientError(TObject *Sender,
      TCustomWinSocket *Socket, TErrorEvent ErrorEvent, int &ErrorCode)
{
  Memo2->Lines->Add(Socket->RemoteAddress + " Error : " + IntToStr(ErrorCode));
  ErrorCode = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ServerSocket1Listen(TObject *Sender,
      TCustomWinSocket *Socket)
{
     Memo2->Lines->Add("Listening...");
}

//---------------------------------------------------------------------------
// Activation Serveur
void __fastcall TForm1::lancerServeurClick(TObject *Sender)
{
  ServerSocket1->Port = Edit6->Text.ToIntDef(5000);
  ServerSocket1->Active = true;
  lancerServeur->Enabled = false;
  Edit6->Enabled = false;
}
//---------------------------------------------------------------------------
int TForm1::nouveauClient(TObject *Sender, TServerWinSocket *Socket)
{
  TMOT *pMot = NULL;

  if (nbClients >= MAXCLI) return(nbClients);

  mot.push_back ( TMOT(nbClients, Socket) );  // nouveau moteur
  pMot = &mot.at(nbClients);

  pMot->RadioButton = new TRadioButton( Form1);
  pMot->RadioButton->Parent = Form1;      // le composant doit appartenir � Form1
  pMot->RadioButton->Top =  30 + 20*nbClients;
  pMot->RadioButton->Left = 224;
  pMot->RadioButton->Width  = 300;
  pMot->RadioButton->Caption = Socket->RemoteAddress;
  pMot->RadioButton->Tag = nbClients;  // pour savoir qui on est
  if ( !nbClients ) pMot->RadioButton->Checked = true;
  pMot->RadioButton->OnClick = RadioButtonClick;

  return(++nbClients);
}
//---------------------------------------------------------------------------
int TForm1::departClient(TObject *Sender, TServerWinSocket *Socket)
{
  --nbClients;
  TMOT *pMot1;
  int i;
  for (i=0 ; i < mot.size() ;  i++) {
    pMot1 = &mot.at(i);
    if (Socket == pMot1->sock ) {

      delete (pMot1->RadioButton);
      pMot1->RadioButton = NULL;

      mot.erase(pMot1); // suppression de la liste

      break;

    }
  }

  for ( ; i < mot.size() ;  i++) {
    pMot1 = &mot.at(i);
    pMot1->RadioButton->Top = 30 + i*20;
  }

  return(nbClients);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButtonClick(TObject *Sender)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
  RefreshMotSor();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  for (int i=0; i<64; i++) {
    // creation Led correspondant aux bits des Mots de Sortie
    pShapeOut[i] = new TShape((TComponent*)Sender);
    pShapeOut[i]->Parent = Form1;
    pShapeOut[i]->Height = 12;
    pShapeOut[i]->Width = 8;
    pShapeOut[i]->Brush->Color = clGray;
    pShapeOut[i]->Tag = i;
    pShapeOut[i]->Top = 80 + (i & 0xF0) ;
    int left = 320 - (16*(i & 0xF) + 4*(i & 0x8) + 2*(i & 0x4));
    pShapeOut[i]->Left = left;

    // creation Led correspondant aux bits des Mots d'Entrees
    pShapeIn[i] = new TShape((TComponent*)Sender);
    pShapeIn[i]->Parent = Form1;
    pShapeIn[i]->Height = 12;
    pShapeIn[i]->Width = 8;
    pShapeIn[i]->Brush->Color = clGray;
    pShapeIn[i]->Tag = i;
    pShapeIn[i]->Top = 180 + (i & 0xF0) ;
    pShapeIn[i]->Left = left;
  }

  for (int i=0; i<16; i++) {
    // creation CheckBox correspondant aux bits du 1er Mot de Sortie
    pCheckBoxOut[i] = new TCheckBox((TComponent*)Sender);
    pCheckBoxOut[i]->Parent = Form1;
    pCheckBoxOut[i]->Height = 10;
    pCheckBoxOut[i]->Width = 10;
    pCheckBoxOut[i]->Tag = i;
    pCheckBoxOut[i]->Top = 30;
    int left = 720 - (12*(i & 0xF) + 3*(i & 0x8) + 1*(i & 0x4)); 
    pCheckBoxOut[i]->Left = left;
    pCheckBoxOut[i]->Visible = true;
    pCheckBoxOut[i]->Enabled = false;
    pCheckBoxOut[i]->OnClick = pCheckBoxClick;

    // creation CheckBox correspondant aux bits du 1er Mot d'Entree
    pCheckBoxIn[i] = new TCheckBox((TComponent*)Sender);
    pCheckBoxIn[i]->Parent = Form1;
    pCheckBoxIn[i]->Height = 10;
    pCheckBoxIn[i]->Width = 10;
    pCheckBoxIn[i]->Tag = i;
    pCheckBoxIn[i]->Top = 190;
    //left = 790 - (12*(i & 0xF) + 3*(i & 0x8) + 1*(i & 0x4));
    pCheckBoxIn[i]->Left = left;
    pCheckBoxIn[i]->Visible = true;
    pCheckBoxIn[i]->Enabled = false;
    pCheckBoxIn[i]->OnClick = pCheckBoxClick;
  }
  //esclave1.Itable[0] = 0x1234;  // pour Debug
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer2Timer(TObject *Sender)
{ // Lancement Automatique du serveur au lancement de l'Appli
  lancerServeurClick(Sender);
  Timer2->Enabled = false;
}
//---------------------------------------------------------------------------
// Selection affichage mot d'entr�e
//---------------------------------------------------------------------------
void __fastcall TForm1::RadioGroup1Click(TObject *Sender)
{
  short sVal =esclave1.Itable [100];
  int iVal = *(int *) &esclave1.Itable [100];
  float fVal = *(float *) &esclave1.Itable [100];
  double dVal = *(double *) &esclave1.Itable [100];
  char szVal[100] ="";

  int choix = RadioGroup1->ItemIndex;
  bool bChoix0 = !choix;
  for (int i=0; i<16; i++) pCheckBoxIn[i]->Enabled = bChoix0;
  Edit1->Visible = !bChoix0;
  BitBtn1->Visible = !bChoix0;

  switch(choix) {
    case 0: for (int i=0; i<16; i++) {
              pCheckBoxIn[i]->Checked = TESTBIT( iVal, i );
            }
            break;
    case 1: sprintf(szVal, "%04hX", sVal); break;
    case 2: sprintf(szVal, "%hd", iVal); break;
    case 3: sprintf(szVal, "%d", iVal); break;
    case 4: sprintf(szVal, "%3.2f", fVal); break;
    case 5: sprintf(szVal, "%3.2lf", dVal); break;
  }
  if (choix > 0) {
    Edit1->Text = szVal;
  }
}
//---------------------------------------------------------------------------
int TForm1::RefreshMotSor()
{
  for (int i=0; i<4; i++) {
    for (int j=0; j<16; j++) {
      if ( esclave1.Itable[i+0] & (1 << j) ) pShapeOut[(i<<4)+j]->Brush->Color = clRed;
      else pShapeOut[(i<<4)+j]->Brush->Color = clGray;
    }
  }
  for (int i=0; i<16; i++) {
    pCheckBoxOut[i]->Checked = TESTBIT(esclave1.Itable[0], i );
  }
  return 0;
}
//---------------------------------------------------------------------------
int TForm1::RefreshMotEnt()
{
  for (int i=0; i<4; i++) {
    for (int j=0; j<16; j++) {
      if ( esclave1.Itable[i+100] & (1 << j) ) pShapeIn[(i<<4)+j]->Brush->Color = clRed;
      else pShapeIn[(i<<4)+j]->Brush->Color = clGray;
    }
  }
  for (int i=0; i<16; i++) {
    pCheckBoxIn[i]->Checked = TESTBIT(esclave1.Itable[100], i );
  }
  return 0;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::pCheckBoxClick(TObject *Sender)
{
  TCheckBox *p = (TCheckBox*)Sender;
  int i = p->Tag;
  if (pCheckBoxIn[i]->Checked) {
    SETBIT(esclave1.Itable [100], i);
    pShapeIn[i]->Brush->Color = clRed;
       }
  else {
    RAZBIT(esclave1.Itable [100], i);
    pShapeIn[i]->Brush->Color = clGray;
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn1Click(TObject *Sender)
{
  int iVal = 0, cr;
  float fVal;
  double dVal;

  int choix = RadioGroup1->ItemIndex;
  switch(choix) {
    case 1:
      cr = sscanf(Edit1->Text.c_str(), "%X", &iVal);
      if (cr > 0) esclave1.Itable [100] = iVal;
      break;
    case 2:
      cr = sscanf(Edit1->Text.c_str(), "%hd", &iVal);
      if (cr > 0) esclave1.Itable [100] = iVal;
      break;
    case 3:
      cr = sscanf(Edit1->Text.c_str(), "%d", &iVal);
      if (cr > 0) *(int *) &esclave1.Itable [100] = iVal;
      break;
    case 4:
      cr = sscanf(Edit1->Text.c_str(), "%f", &fVal);
      if (cr > 0) *(float*) &esclave1.Itable [100] = fVal;
      break;
    case 5:
      cr = sscanf(Edit1->Text.c_str(), "%lf", &dVal);
      if (cr > 0) *(double*) &esclave1.Itable [100] = dVal;
  }
  RefreshMotEnt();
}
//---------------------------------------------------------------------------
// Selection affichage mot de sortie
//---------------------------------------------------------------------------
void __fastcall TForm1::RadioGroup2Click(TObject *Sender)
{
  short sVal =esclave1.Itable [0];
  int iVal = *(int *) &esclave1.Itable [0];
  float fVal = *(float *) &esclave1.Itable [0];
  double dVal = *(double *) &esclave1.Itable [0];
  char szVal[100] ="";

  int choix = RadioGroup2->ItemIndex;
  bool bChoix0 = !choix;
  //for (int i=0; i<16; i++) pCheckBoxOut[i]->Enabled = bChoix0;
  Edit3->Visible = !bChoix0;

  switch(choix) {
    case 0: for (int i=0; i<16; i++) {
              pCheckBoxOut[i]->Checked = TESTBIT( iVal, i );
            }
            break;
    case 1: sprintf(szVal, "%04hX", sVal); break;
    case 2: sprintf(szVal, "%hd", iVal); break;
    case 3: sprintf(szVal, "%d", iVal); break;
    case 4: sprintf(szVal, "%3.2f", fVal); break;
    case 5: sprintf(szVal, "%3.2lf", dVal); break;
  }
  if (choix > 0) {
    Edit3->Text = szVal;
  }
}
//---------------------------------------------------------------------------

