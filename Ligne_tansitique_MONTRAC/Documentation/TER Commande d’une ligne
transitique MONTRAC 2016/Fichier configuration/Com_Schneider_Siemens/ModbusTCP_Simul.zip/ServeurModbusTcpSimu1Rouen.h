//---------------------------------------------------------------------------

#ifndef ServeurModbusTcpSimu1RouenH
#define ServeurModbusTcpSimu1RouenH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ScktComp.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include <Mask.hpp>
#include <Buttons.hpp>
#include <vector>
#include <algorithm>
#include <stdio.h>
#include <excpt.h>

//#include "trames_esclave_ModbusTCP.h"
#include "trames_esclave_ModbusTCP_23.h"
//---------------------------------------------------------------------------
#define MAXCLI  1
//---------------------------------------------------------------------------
// tstbit.h  macros                            B.Vannier      fev 2012
//---------------------------------------------------------------------------
// definition de macros pour mise a 1 et reset de bits
#define SETBIT(x,n)  ((x)|=1<<(n))
#define RAZBIT(x,n)  ((x)&= ~(1<<(n)))
// definition de macros pour tester 1 bit dans une variable
#define TESTBIT(x,n)   ((x)&(1<<(n)))>>(n) // x: valeur a tester, n : no du bit
//---------------------------------------------------------------------------
//  TSOCK : utilis� pour le classement des socket clients
//---------------------------------------------------------------------------
class TMOT {  //  classe Moteur
  public:
    int no, cmd, max, etat, vit;
    bool sens;
    TRadioButton *RadioButton;
    TCustomWinSocket	*sock;
    TMOT(int no_, TCustomWinSocket	*sock_) {
      no = no_; sock = sock_;
      cmd = 0; vit=0; etat=0; sens=true, max = 0;
      RadioButton = NULL;
    }
};
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// Composants g�r�s par l'EDI
  TMemo *Memo2;
  TServerSocket *ServerSocket1;
  TEdit *Edit2;
  TLabel *Label2;
  TLabel *Label4;
  TLabel *Label6;
  TEdit *Edit6;
  TButton *lancerServeur;
  TTimer *Timer1;
  TCheckBox *CheckBox1;
  TProgressBar *ProgressBar1;
  TLabel *Label1;
  TLabel *Label3;
  TLabel *Label5;
  TTimer *Timer2;
  TRadioGroup *RadioGroup1;
  TBitBtn *BitBtn1;
  TEdit *Edit1;
  TRadioGroup *RadioGroup2;
  TEdit *Edit3;
  void __fastcall ServerSocket1Accept(TObject *Sender,
          TCustomWinSocket *Socket);
  void __fastcall ServerSocket1ClientConnect(TObject *Sender,
          TCustomWinSocket *Socket);
  void __fastcall ServerSocket1ClientDisconnect(TObject *Sender,
          TCustomWinSocket *Socket);
  void __fastcall ServerSocket1ClientRead(TObject *Sender,
          TCustomWinSocket *Socket);
  void __fastcall ServerSocket1ClientError(TObject *Sender,
          TCustomWinSocket *Socket, TErrorEvent ErrorEvent,
          int &ErrorCode);
  void __fastcall ServerSocket1Listen(TObject *Sender,
          TCustomWinSocket *Socket);
  void __fastcall lancerServeurClick(TObject *Sender);
  void __fastcall Timer1Timer(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall Timer2Timer(TObject *Sender);
  void __fastcall RadioGroup1Click(TObject *Sender);
  void __fastcall BitBtn1Click(TObject *Sender);
  void __fastcall RadioGroup2Click(TObject *Sender);
private:	// D�clarations de l'utilisateur
  void __fastcall RadioButtonClick(TObject *Sender);
  int nouveauClient(TObject *Sender, TServerWinSocket *Socket);
  int departClient(TObject *Sender, TServerWinSocket *Socket);
  AnsiString* TForm1::ToHexa(AnsiString* As, char *buf, int lg);
  int RefreshMotSor();
  int RefreshMotEnt();
  int nbClients;
  int indexCli;
  //TRadioButton *RadioButton[MAXCLI];
  String Server;
  TESCLAVE_M esclave1;  // Classe contenant l'�mulateur de protocole MODBUS TCP

  char bufrec[1000];
  std::vector<TMOT> mot; // vecteur sur les "moteurs"
  //int vit;  // [MAXCLI]
  //int etat;
  //bool sens;
  TShape *pShapeIn[64], *pShapeOut[64];
  TCheckBox *pCheckBoxIn[16];   // on peut forcer la valeur des bits du Mot 100
  TCheckBox *pCheckBoxOut[16];
  void __fastcall pCheckBoxClick(TObject *Sender);

public:		// D�clarations de l'utilisateur
  __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
