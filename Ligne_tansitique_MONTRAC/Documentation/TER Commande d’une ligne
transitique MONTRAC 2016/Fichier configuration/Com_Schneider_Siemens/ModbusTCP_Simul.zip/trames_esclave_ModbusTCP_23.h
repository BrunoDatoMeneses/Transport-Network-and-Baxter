//////////////////////////////////////////////////////////////////////////////
//	Projet :             	ESCLAVE MODBUS            		B.VANNIER FEV 2011
//	Fichiers du projet:
//               trames_esclave_ModbusTCP.CPP   Construction des trames r�ponses
//////////////////////////////////////////////////////////////////////////////
// Ce fichier :	trames_esclave_Modicon.H
//////////////////////////////////////////////////////////////////////////////
#ifndef trames_esclaveH
#define trames_esclaveH

#define			  MAXMOTS	255 // taille de la table des mots MODBUS -1
#define			  MAXBITS	1023 // taille de la table des bits MODBUS -1
typedef unsigned char uchar;

// R�f�rences externes
//extern int		  Itable[MAXMOTS + 1];		// Tableau des valeurs modbus

class TESCLAVE
{
private:
protected:

public:
};
//----------------------------------------------------------------------------
// Version Modbus TCP (sans CRC)
//----------------------------------------------------------------------------
// Modbus_to_Tcp : adapte la trame Modbus d'origine avec CRC � la trame
//  modbus TCP sans CRC
// La trame MODBUS r�elle commence en buffer_[6] (no d'esclave
//   ou unit identifier dans la nouvelle terminologie)
//---------------------------------------------------------------------------

class TESCLAVE_M
{
private:
    unsigned short int __fastcall mot(uchar fort, uchar faible){
        return(((fort<<8)&0xFF00) | (faible & 0xFF));}
    int __fastcall lect_bits_(uchar *trame_emi, uchar *trame_rec, int lgtrame);  // 1 ou 2
    int __fastcall lect_mots_(uchar *trame_emi, uchar *trame_rec, int lgtrame);  // 3 ou 4
    int __fastcall ecri_bits_(uchar *trame_emi, uchar *trame_rec, int lgtrame);  // 15
    int __fastcall ecri_mots_(uchar *trame_emi, uchar *trame_rec, int lgtrame);  // 16
    int __fastcall ecri_1mot_(uchar *trame_emi, uchar *trame_rec, int lgtrame);  // 6
    int __fastcall lect_ecri_mots_(uchar *trame_emi, uchar *trame_rec, int lgtrame); // 23
//    int       NumEsclave;
public:
    short int Itable[MAXMOTS + 1];	//	Tableau des mots MODBUS
    uchar   Btable[MAXBITS + 1];	//	Tableau des bits MODBUS
    bool bMotsEcrits[16]; // tableau indiquant les derniers mots ayant �t� �crits

    TESCLAVE_M();     // constructeur
    int __fastcall repond_(uchar *trame_emi, uchar *trame_rec, int lgtrame);
private:
    int head(uchar *trame_emi, int nb){  // construit l'ent�te de la tame r�ponse TCP_Modbus
      trame_emi[0] = 0; trame_emi[1] = 0;trame_emi[2] = 0;trame_emi[3] = 0;trame_emi[4] = 0;
      trame_emi[5] = (nb-2) & 0xFF; // longueur trame (sans CRC) poids faibles
      return (nb+4); // longueur de la nouvelle trame sans CRC mais avec entete
    }
    int __fastcall lect_bits(uchar *trame_emi, uchar *trame_rec, int lgtrame){  // 1 ou 2
      int nb =lect_bits_(&trame_emi[6], &trame_rec[6], lgtrame-4);
      return (head(trame_emi, nb));
    }
    int __fastcall lect_mots(uchar *trame_emi, uchar *trame_rec, int lgtrame){  // 3 ou 4
      int nb =lect_mots_(&trame_emi[6], &trame_rec[6], lgtrame-4);
      return (head(trame_emi, nb));
    }
    int __fastcall ecri_bits(uchar *trame_emi, uchar *trame_rec, int lgtrame){  // 15
      int nb =ecri_bits_(&trame_emi[6], &trame_rec[6], lgtrame-4);
      return (head(trame_emi, nb));
    }
    int __fastcall ecri_mots(uchar *trame_emi, uchar *trame_rec, int lgtrame){  // 16
      int nb =ecri_mots_(&trame_emi[6], &trame_rec[6], lgtrame-4);
      return (head(trame_emi, nb));
    }
    int __fastcall ecri_1mot(uchar *trame_emi, uchar *trame_rec, int lgtrame){  // 6
      int nb =ecri_1mot_(&trame_emi[6], &trame_rec[6], lgtrame-4);
      return (head(trame_emi, nb));
    }
    int __fastcall lect_ecri_mots(uchar *trame_emi, uchar *trame_rec, int lgtrame){  // 23
      int nb =lect_ecri_mots_(&trame_emi[6], &trame_rec[6], lgtrame-4);
      return (head(trame_emi, nb));
    }
public:
    int __fastcall repond(uchar *trame_emi, uchar *trame_rec, int lgtrame);
    short int nes( uchar *trame_rec ){return(trame_rec[6]);}  // renvoie le no d'esclave 20/02/06
};

#endif
