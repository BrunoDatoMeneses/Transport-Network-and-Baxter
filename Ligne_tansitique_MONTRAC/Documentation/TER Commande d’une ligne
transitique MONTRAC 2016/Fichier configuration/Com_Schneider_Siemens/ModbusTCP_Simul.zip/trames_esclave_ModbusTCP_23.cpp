//---------------------------------------------------------------------------
//	Projet :         SIMULATION	ESCLAVE MODBUS             	B.VANNIER  2011
//  Version avec code 23
//	Fichiers du projet:
// Ce fichier :	trames_esclave_ModbusTCP_23.CPP
//---------------------------------------------------------------------------
//  Auteur  : B.Vannier
//	 Modifs :
//  Simule un esclave MODBUS TCP:
// - analyse des trames et construction d'une trame r�ponse
// - Renvoi des trames r�ponse (vers le ma�tre)
//   les trames d'�criture et lecture agissent sur une table de 256 mots
//   Codes Trait�s : 1 ou 2 lecture bits    modif du 5 juil 2000
//                   3 ou 4 lecture mots
//                   6 �criture 1 mot
//                  15 �criture bits        modif du 5 juil 2000
//                  16 �criture plusieurs mots
//                  23 lecture/ecriture          20 fev 2013
//---------------------------------------------------------------------------
// Modifs:
//  20/02/13: Rajout du code 23 lecture/ecriture
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "trames_esclave_ModbusTCP_23.h"

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
TESCLAVE_M::TESCLAVE_M()     // constructeur
{
  short int i;
  for (i=4; i<=MAXMOTS; i++) Itable[i] = 0;   //i + 512;
  for (i=0; i<16; i++) bMotsEcrits[i] = false;
}

//---------------------------------------------------------------------------
//   lect_bits() : construit la trame r�ponse treme_emi pour la requ�te lecture bits 01
//---------------------------------------------------------------------------
int __fastcall TESCLAVE_M::lect_bits_(uchar *trame_emi, uchar *trame_rec, int lgtrame)
{
    int i, j, ad, nbbits, nb_octets;
    short int valeur, crc;
    uchar octet;

    if (lgtrame != 8) return(-1);
    ad = mot(trame_rec[2], trame_rec[3]);
    nbbits = mot(trame_rec[4], trame_rec[5]);
    nb_octets = (nbbits + 7) >> 3 ;
    if (nbbits < 1) return (-2);
    if ((ad < 0) || (ad + nbbits > 1023)) return(-3);
    trame_emi[0] = trame_rec[0];  // n� esclave
    trame_emi[1] = trame_rec[1];  // code fonction
    trame_emi[2] = (uchar)nb_octets;   // nb d'octets
    for (i=0; i < nb_octets; i++){   // octet par octet
        octet = 0;
        for (j=1; j<0x100; j <<= 1) {             // puis bit par bit
            if (Btable[ad++]!=0) octet |= j;       // mise a 1 du bit ?
        }
        trame_emi[3 + i] = octet;  
    }
    // raz des derniers bits non demand�s
    int nb_bits_non_demandes = (nb_octets << 3) - nbbits;
    for (i=0, j=0xFF7F; i < nb_bits_non_demandes; i++, j>>=1){
        trame_emi[2 + nb_octets] &= (uchar)j;
    }

    //int nb_o = nb_octets + 3;  // nb d'octets de la trame
    //crc = CRC_16(trame_emi, nb_o);
    //trame_emi[nb_o++] = (uchar)(crc & 0xFF);
    //trame_emi[nb_o++] = (uchar)((crc  & 0xFF00) >> 8);
    return(nb_octets + 1);
}
//---------------------------------------------------------------------------
//   lect_mots() : construit la trame r�ponse treme_emi pour la requ�te lecture mot
//---------------------------------------------------------------------------
int __fastcall TESCLAVE_M::lect_mots_(uchar *trame_emi, uchar *trame_rec, int lgtrame)
{
  int i, ad, nbmots, no_octet;
  short int valeur, crc;

  if (lgtrame != 8) return(-1);
  ad = mot(trame_rec[2], trame_rec[3]);
  nbmots = mot(trame_rec[4], trame_rec[5]);
  if (nbmots < 1) return (-2);
  if ((ad < 0) || (ad + nbmots > 255)) return(-3);
  trame_emi[0] = trame_rec[0];  // n� esclave
  trame_emi[1] = trame_rec[1];  // code fonction
  trame_emi[2] = (uchar)(nbmots << 1);   // nb d'octets lus
  no_octet = 3;
  for (i=0; i<nbmots; i++) {
    valeur = Itable[ad + i];
    trame_emi[no_octet++] = (uchar)((valeur & 0xFF00) >> 8); // poids forts
    trame_emi[no_octet++] = (uchar)(valeur & 0xFF);          // poids faibles
  }
  //crc = CRC_16(trame_emi, no_octet);
  //trame_emi[no_octet++] = (uchar)(crc & 0xFF);
  //trame_emi[no_octet++] = (uchar)((crc  & 0xFF00) >> 8);
  return(no_octet + 2);
}
//---------------------------------------------------------------------------
//  ecri_bits  : ecriture dans Btable (table des bits MODBUS)   code 15
//               et construction de la trame �mission
//---------------------------------------------------------------------------
int __fastcall TESCLAVE_M::ecri_bits_(uchar *trame_emi, uchar *trame_rec, int lgtrame)
{
    int i, j, ad, nbbits, nb_octets;
    short int crc;
    uchar octet;

    if (lgtrame < 8) return(-1);
    ad = mot(trame_rec[2], trame_rec[3]);
    nbbits = mot(trame_rec[4], trame_rec[5]);
    nb_octets = (nbbits +7) >> 3;
    if (nbbits < 1) return (-2);
    if ((ad < 0) || (ad + nbbits > 1023)) return(-3);

  // �criture dans la table des valeurs :
    for (i = 0; i < nb_octets; i++){
        octet = trame_rec[i+7] & (uchar)0xFF;
        for (j=0; j<8; j++) {             // puis bit par bit
            if (((octet >> j) & 1) != 0) Btable[ad++] = 1;
                                    else Btable[ad++] = 0;
            if ( ((i<<3) + j) >= nbbits) break;
        }
    }
    // construction trame r�ponse:
    memcpy(trame_emi, trame_rec, 6);
    //crc = CRC_16(trame_emi, 6);
    //trame_emi[6] = (uchar)(crc & 0xFF);
    //trame_emi[7] = (uchar)((crc  & 0xFF00) >> 8);
    return(6);    // nb d'octets
}
//---------------------------------------------------------------------------
//  ecri_mots  : ecriture dans Itable (table des mots MODBUS)   code 16
//               et construction de la trame �mission
//---------------------------------------------------------------------------
int __fastcall TESCLAVE_M::ecri_mots_(uchar *trame_emi, uchar *trame_rec, int lgtrame)
{
  int i, j, ad, nbmots;
  short int crc;

  if (lgtrame < 8) return(-1);
  ad = mot(trame_rec[2], trame_rec[3]);
  nbmots = mot(trame_rec[4], trame_rec[5]);
  if (nbmots < 1) return (-2);
  if ((ad < 0) || (ad + nbmots > 255)) return(-3);

  // �criture dans la table des valeurs :
  for (i=ad, j=7; i < ad+nbmots; i++, j+=2){
	  Itable[i] = ((trame_rec[j]&0xFF) << 8) | (trame_rec[j+1] & 0xFF) ;
    //if (ad < 16) bMotsEcrits[i] = true;  // indicateur d'�criture
  }

  memcpy(trame_emi, trame_rec, 8);         // ## 28 juil 2011
  //crc = CRC_16(trame_emi, 6);
  //trame_emi[6] = (uchar)(crc & 0xFF);
  //trame_emi[7] = (uchar)((crc  & 0xFF00) >> 8);
  return(8);    // nb d'octets
}
//---------------------------------------------------------------------------
//  ecri_1mot  : ecriture dans tab_modbus   code 6
//               et construction de la trame �mission
//---------------------------------------------------------------------------
int __fastcall TESCLAVE_M::ecri_1mot_(uchar *trame_emi, uchar *trame_rec, int lgtrame)
{
  int i, j, ad, nbmots;
  //short int crc;

  if (lgtrame != 8) return(-1);
  ad = mot(trame_rec[2], trame_rec[3]);
  if ((ad < 0) || (ad > 255)) return(-3);

  // �criture dans la table des valeurs :
  Itable[ad] = ((trame_rec[4]&0xFF) << 8) | (trame_rec[5] & 0xFF) ;

  //if (ad < 16) bMotsEcrits[ad] = true;  // indicateur d'�criture


  memcpy(trame_emi, trame_rec, 6);
  //crc = CRC_16(trame_emi, 6);
  //trame_emi[6] = (uchar)(crc & 0xFF);
  //trame_emi[7] = (uchar)((crc  & 0xFF00) >> 8);
  return(6);    // nb d'octets
}
//---------------------------------------------------------------------------
//  lect_ecri_mots  : Lecture et  ecriture dans Itable (table des mots MODBUS)
//       et construction de la trame �mission       code 23   fev 2013
//---------------------------------------------------------------------------
int __fastcall TESCLAVE_M::lect_ecri_mots_(uchar *trame_emi, uchar *trame_rec, int lgtrame)
{
  int i, j, adLec, adEcri, nbmotsLec, nbmotsEcri;
  short int crc, valeur;

  if (lgtrame < 11) return(-1);

  adLec = mot(trame_rec[2], trame_rec[3]);
  nbmotsLec = mot(trame_rec[4], trame_rec[5]);
  if (nbmotsLec < 1) return (-2);
  if ((adLec < 0) || (adLec + nbmotsLec > 255)) return(-3);

  adEcri = mot(trame_rec[6], trame_rec[7]);
  nbmotsEcri = mot(trame_rec[8], trame_rec[9]);
  if (nbmotsEcri < 1) return (-2);
  if ((adEcri < 0) || (adEcri + nbmotsEcri > 255)) return(-3);

  // �criture dans la table des valeurs :
  for (i=adEcri, j=11; i < adEcri + nbmotsEcri; i++, j+=2){
	  Itable[i] = ((trame_rec[j]&0xFF) << 8) | (trame_rec[j+1] & 0xFF) ;
    //if (adEcri < 16) bMotsEcrits[i] = true;  // indicateur d'�criture
  }

  // lecture dans la table des valeurs et construction trame retour :
  memcpy(trame_emi, trame_rec, 2);
  trame_emi[0] = trame_rec[0];    // nes
  trame_emi[1] = trame_rec[1];    // code fonc
  trame_emi[2] = nbmotsEcri << 1; // nb octets
  j = 3;
  for (i=0; i<nbmotsLec; i++) {
    valeur = Itable[adLec + i];
    trame_emi[j++] = (uchar)((valeur & 0xFF00) >> 8); // poids forts
    trame_emi[j++] = (uchar)(valeur & 0xFF);          // poids faibles
  }

  return(j+2);    // nb d'octets
}
//---------------------------------------------------------------------------
//   repond_() : analyse trame_rec et construit la trame r�ponse trame_emi
//---------------------------------------------------------------------------
int __fastcall TESCLAVE_M::repond_(uchar *trame_emi, uchar *trame_rec, int lgtrame)
{
  int cr;
  if (lgtrame < 8) return(-11);  // trame trop courte
  //if (!test_crc( trame_rec, lgtrame)) return(-5);   // erreur CRC
//  if (trame_rec[0] != NumEsclave) return(-12);  n� d'esclave : non test�
  switch (trame_rec[1]) {
    case 1:
    case 2: cr = lect_bits(trame_emi, trame_rec, lgtrame);
            break;
    case 3:
    case 4: cr = lect_mots(trame_emi, trame_rec, lgtrame);
            break;
    case 6: cr = ecri_1mot(trame_emi, trame_rec, lgtrame);
            break;
    case 15:cr = ecri_bits(trame_emi, trame_rec, lgtrame);
            break;
    case 16:cr = ecri_mots(trame_emi, trame_rec, lgtrame);
            break;
    case 23:cr = lect_ecri_mots(trame_emi, trame_rec, lgtrame);
            break;
    default: return(-13);    // code fonction non trait�
  }
  return (cr);  //retourne le nombre d'octets de la trame ou un code d'erreur
}

//---------------------------------------------------------------------------
//   TCP_Modicon: repond() : analyse trame_rec et construit la trame r�ponse trame_emi
//---------------------------------------------------------------------------
int __fastcall TESCLAVE_M::repond(uchar *trame_emi, uchar *trame_rec, int lgtrame)
{
  int cr;
  //for (int i=0; i<16; i++) bMotsEcrits[i] = false;   // RAz mots �crits

  if (lgtrame < 12) return(-11);  // trame trop courte

  switch (trame_rec[7]) {
    case 1:
    case 2: cr = lect_bits(trame_emi, trame_rec, lgtrame);
            break;
    case 3:
    case 4: cr = lect_mots(trame_emi, trame_rec, lgtrame);
            break;
    case 6: cr = ecri_1mot(trame_emi, trame_rec, lgtrame);
            break;
    case 15:cr = ecri_bits(trame_emi, trame_rec, lgtrame);
            break;
    case 16:cr = ecri_mots(trame_emi, trame_rec, lgtrame);
            break;
    case 23:cr = lect_ecri_mots(trame_emi, trame_rec, lgtrame);
            break;
    default: return(-13);    // code fonction non trait�
  }
  trame_emi[0]= trame_rec[0];  // renvoyer le transac ID
  trame_emi[1]= trame_rec[1];
  return (cr);  //retourne le nombre d'octets de la trame ou un code d'erreur
}


