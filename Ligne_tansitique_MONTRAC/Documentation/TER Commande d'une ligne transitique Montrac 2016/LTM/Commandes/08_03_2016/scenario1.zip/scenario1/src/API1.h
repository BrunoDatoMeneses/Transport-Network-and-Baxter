#ifndef API1
#define API1

#include <ros/ros.h>
#include "scenario1/EntreesSorties.h"

class AP1
{
private:

public:

};



#endif
