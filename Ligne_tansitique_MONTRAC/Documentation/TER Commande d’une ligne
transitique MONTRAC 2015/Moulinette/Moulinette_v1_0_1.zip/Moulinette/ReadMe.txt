Bienvenue dans le fichier Liszemoi de Moulinex. Ce fichier contient des informations essentielles sur Moulinex.

- Configuration syst�me requise:

	Etre sous Windows.

- Instruction d'installation:

	Mettez le dossier 'Moulinette' o� bon vous semble et cr�ez vous un raccourci sur le bureau pour �viter de gal�rer � chercher le programme.

- Pour d�sinstaller Moulinex sous Windows:

	Supprimez le dossier 'Moulinette'.

- Informations sur les mises � jour:

	V1.0.0: Cette application a pour but de g�n�rer du code en langage ST � partir d'un fichier de mod�lisation sous le logiciel Tina (*.ndr).
	v1.0.1: Ajout de l'ouverture du dossier o� se trouve le fichier moulin�.


- Informations juridiques: 

	Copyright (C) 2015 Moulinex, sur une id�e de C�dric Abiven, Gr�goire Cardone et Shengheng Gao. D�velopp� pour faciliter le codage sur automate Schneider � l'AIPPRIMECA, Universit� Paul Sabatier, Toulouse.

	Cette application n'a aucun rapport avec la marque Moulinex TM.

- Liens annexes:

	Pour plus d'informations sur le logiciel TINA, visitez cette page: http://projects.laas.fr/tina//